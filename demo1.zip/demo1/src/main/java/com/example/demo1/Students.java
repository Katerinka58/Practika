package com.example.demo1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Students {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField Year;

    @FXML
    private TableColumn<?, ?> Year_table;

    @FXML
    private Button back_button;

    @FXML
    private DatePicker data;

    @FXML
    private TableColumn<?, ?> data_table;

    @FXML
    private Button dell_button;

    @FXML
    private Button edit_button;

    @FXML
    private TextField fullName_students;

    @FXML
    private TableColumn<?, ?> fullName_table;

    @FXML
    private SplitMenuButton kind_of_sport;

    @FXML
    private TextField login;

    @FXML
    private TableColumn<?, ?> login_table1;

    @FXML
    private TextField number_group;

    @FXML
    private TableColumn<?, ?> number_group_table;

    @FXML
    private TextField phone_number;

    @FXML
    private TableColumn<?, ?> phone_number_table;

    @FXML
    void initialize() {
    }
@FXML
void setBack_button(){
        back_button.getScene().getWindow();
    FXMLLoader loader = new FXMLLoader();
    loader.setLocation(getClass().getResource("A.fxml"));
    try {
        loader.load();
    }catch (IOException e) {
        e.printStackTrace();
    }
    Parent root = loader.getRoot();
    Stage stage = new Stage();
    stage.setScene(new Scene(root));
    stage.show();
}
}
