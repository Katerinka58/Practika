package com.example.demo1;

import java.net.Socket;

public class Server {
    Socket server =new Socket();
}
